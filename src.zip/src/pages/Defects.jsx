import React from "react";

export default function Defects() {
  return <div>Defects</div>;
}

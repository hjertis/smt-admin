function NoopWrapper(props) {
  return props.children
}

export default NoopWrapper

import React from "react";

export default function EditEvent(props) {
  return (
    <div>
      <h1>hello</h1>
    </div>
  );
}
